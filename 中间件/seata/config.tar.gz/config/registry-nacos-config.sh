#!/usr/bin/env bash
sh nacos-config.sh -h www.lhy-aliyun.com